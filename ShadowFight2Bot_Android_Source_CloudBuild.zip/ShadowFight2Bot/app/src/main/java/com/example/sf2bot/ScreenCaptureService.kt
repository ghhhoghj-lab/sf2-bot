package com.example.sf2bot

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Prototype perception: samples a narrow horizontal band and estimates the two
 * darkest connected regions. This is NOT a trained SF2 detector; background,
 * effects and UI can fool it. Actions are conservative and limited to a small
 * set of screen-relative coordinates.
 */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastAction = 0L
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopSelf() }
    }
    private var frameCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(27, makeNotification())
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java)
                   else @Suppress("DEPRECATION") intent?.getParcelableExtra("resultData")
        if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        projection?.registerCallback(projectionCallback, Handler(mainLooper))
        startCapture()
        return START_NOT_STICKY
    }

    private fun makeNotification(): Notification {
        val channelId = "sf2bot_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "SF2 Bot screen analysis", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return Notification.Builder(this, channelId)
            .setContentTitle("SF2 Bot active")
            .setContentText("Screen analysis is running. Stop it from the app.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    private fun startCapture() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        thread = HandlerThread("sf2-capture").also { it.start() }
        handler = Handler(thread!!.looper)
        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                frameCount++
                if (frameCount % 5 == 0) analyze(image, w, h)
            } finally { image.close() }
        }, handler)
        display = projection?.createVirtualDisplay(
            "SF2BotDisplay", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
    }

    private fun analyze(image: Image, width: Int, height: Int) {
        val now = System.currentTimeMillis()
        if (now - lastAction < 500) return
        val bot = BotAccessibilityService.instance ?: return
        if (!bot.isBotEnabled()) return

        // ImageReader buffer has row padding; sample a mid-height band.
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val y = (height * 0.64f).toInt().coerceIn(0, height - 1)
        val xStart = (width * 0.08f).toInt()
        val xEnd = (width * 0.92f).toInt()
        var darkestX = -1
        var darkest = 255
        var darkCount = 0
        var x = xStart
        while (x < xEnd) {
            val idx = y * rowStride + x * pixelStride
            if (idx + 2 < buffer.capacity()) {
                val rr = buffer.get(idx).toInt() and 255
                val gg = buffer.get(idx + 1).toInt() and 255
                val bb = buffer.get(idx + 2).toInt() and 255
                val lum = (rr * 30 + gg * 59 + bb * 11) / 100
                if (lum < 65) {
                    darkCount++
                    if (lum < darkest) { darkest = lum; darkestX = x }
                }
            }
            x += 6
        }

        // Prototype rule: only act when the sampled line contains dark pixels.
        // Relative controls are approximate and must be calibrated per device.
        if (darkestX >= 0 && darkCount > 4) {
            val attackX = width * 0.88f
            val attackY = height * 0.82f
            val kickX = width * 0.78f
            val kickY = height * 0.82f
            val distanceFromCenter = abs(darkestX - width / 2)
            if (distanceFromCenter < width * 0.25f) {
                bot.tap(attackX, attackY)
            } else {
                bot.tap(kickX, kickY)
            }
            lastAction = now
        }
    }

    override fun onDestroy() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        thread?.quitSafely()
        BotAccessibilityService.instance?.stopBot()
        super.onDestroy()
    }
}
