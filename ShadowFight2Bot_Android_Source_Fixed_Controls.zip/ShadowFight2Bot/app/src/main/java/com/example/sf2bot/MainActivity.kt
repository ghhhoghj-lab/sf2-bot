package com.example.sf2bot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 501
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        status = TextView(this).apply { text = "SF2 Bot — экспериментальный прототип\n\n1) Разреши службу доступности.\n2) Нажми Старт и подтверди захват экрана.\n3) Перейди в Shadow Fight 2.\n\nСначала проверь в тренировочном/обычном бою." }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Открыть настройки доступности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Старт — разрешить экран"
            setOnClickListener {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
            }
        })
        layout.addView(Button(this).apply {
            text = "Стоп"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                BotAccessibilityService.instance?.stopBot()
                status.text = "Бот остановлен."
            }
        })
        layout.addView(Button(this).apply {
            text = "Открыть настройки приложения"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android but supported for this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }
            startForegroundService(i)
            BotAccessibilityService.instance?.startBot()
            status.text = "Захват экрана включён. Перейди в игру. Нажми Стоп, чтобы завершить."
            Toast.makeText(this, "Разрешение получено", Toast.LENGTH_SHORT).show()
        }
    }
}
