package com.shadowpilot.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BotAccessibilityService? = null }
    @Volatile private var enabled = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { stopBot() }
    override fun onDestroy() { if (instance === this) instance = null; enabled = false; super.onDestroy() }

    fun startBot() { enabled = true }
    fun stopBot() { enabled = false }
    fun isBotEnabled() = enabled

    fun tap(x: Float, y: Float, durationMs: Long = 65L) {
        if (!enabled || x < 0f || y < 0f) return
        val path = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build(), null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 180L) {
        if (!enabled) return
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build(), null, null)
    }
}
