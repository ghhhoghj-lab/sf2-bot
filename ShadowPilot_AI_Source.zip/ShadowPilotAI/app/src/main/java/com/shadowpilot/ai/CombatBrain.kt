package com.shadowpilot.ai

import android.media.Image
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Lightweight heuristic controller, not a trained neural network. */
internal class CombatBrain {
    data class Scene(val playerX: Float, val enemyX: Float, val confidence: Float) {
        val distance get() = abs(enemyX - playerX)
    }
    enum class Move { APPROACH, PUNCH, KICK, THROW, MAGIC, RETREAT, GUARD }
    data class Decision(val move: Move, val reason: String)

    private var lastThrow = 0L
    private var lastMagic = 0L
    private var lastGuard = 0L
    private var comboIndex = 0
    private var previousDistance = .5f

    fun analyze(image: Image): Scene? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val w = image.width
        val h = image.height
        if (w < h) return null // game should be in landscape
        val yStart = (h * .35f).toInt().coerceIn(0, h - 1)
        val yEnd = (h * .82f).toInt().coerceIn(yStart + 1, h)
        val xStart = (w * .12f).toInt()
        val xEnd = (w * .88f).toInt()
        val stepX = max(3, w / 300)
        val stepY = max(3, h / 100)
        val scores = FloatArray(w)
        var x = xStart
        while (x < xEnd) {
            var score = 0f
            var y = yStart
            while (y < yEnd) {
                val idx = y * rowStride + x * pixelStride
                if (idx + 2 < buffer.capacity()) {
                    val r = buffer.get(idx).toInt() and 255
                    val g = buffer.get(idx + 1).toInt() and 255
                    val b = buffer.get(idx + 2).toInt() and 255
                    val lum = (r * 30 + g * 59 + b * 11) / 100
                    // Dark silhouettes are common in SF2, but avoid counting pure black margins.
                    if (lum < 68 && (max(r, max(g, b)) - min(r, min(g, b)) < 95)) score += 1f
                }
                y += stepY
            }
            scores[x] = score
            x += stepX
        }
        // Find two distinct silhouette-like peaks anywhere in the combat lane. Fighters
        // can move around, so fixed left/right halves are too brittle.
        val candidates = ArrayList<Pair<Int, Float>>()
        val desiredStart = (w * .18f).toInt().coerceAtLeast(1)
        var candidateX = xStart + (((desiredStart - xStart).coerceAtLeast(0) + stepX - 1) / stepX) * stepX
        val end = (w * .86f).toInt().coerceAtMost(w - 2)
        while (candidateX < end) {
            val smooth = scores[candidateX] + scores[candidateX - stepX] * .45f + scores[candidateX + stepX] * .45f
            val leftSmooth = scores[(candidateX - stepX * 2).coerceAtLeast(0)]
            val rightSmooth = scores[(candidateX + stepX * 2).coerceAtMost(w - 1)]
            if (smooth >= leftSmooth && smooth >= rightSmooth && smooth > 2.5f) candidates.add(candidateX to smooth)
            candidateX += stepX
        }
        if (candidates.size < 2) return null
        val strongest = candidates.sortedByDescending { it.second }
        var first: Pair<Int, Float>? = null
        var second: Pair<Int, Float>? = null
        for (candidate in strongest) {
            if (first == null) first = candidate
            else if (abs(candidate.first - first.first) > w * .085f) { second = candidate; break }
        }
        val f1 = first ?: return null
        val f2 = second ?: return null
        val ordered = listOf(f1, f2).sortedBy { it.first }
        val player = ordered[0]
        val enemy = ordered[1]
        val confidence = (min(player.second, enemy.second) / max(1f, (yEnd - yStart).toFloat() / stepY)).coerceIn(0f, 1f)
        if (confidence < .08f) return null
        return Scene(player.first / w.toFloat(), enemy.first / w.toFloat(), confidence)
    }

    fun decide(scene: Scene, now: Long): Decision {
        val d = scene.distance
        val closing = d < previousDistance - .012f
        previousDistance = d
        if (scene.confidence < .08f) return Decision(Move.APPROACH, "Слабая уверенность: сближение")
        if (d > .34f) {
            if (now - lastThrow > 2600L) { lastThrow = now; return Decision(Move.THROW, "Противник далеко: метательное оружие") }
            return Decision(Move.APPROACH, "Большая дистанция: сближение")
        }
        if (d > .22f) {
            if (now - lastMagic > 9500L && Random.nextFloat() < .28f) { lastMagic = now; return Decision(Move.MAGIC, "Средняя дистанция: шанс применить магию") }
            return if (closing) Decision(Move.GUARD, "Противник приближается: короткая защита") else Decision(Move.APPROACH, "Средняя дистанция: занять позицию")
        }
        // Close-range action selection with bounded, varied combos.
        if (now - lastGuard > 6500L && Random.nextFloat() < .12f) { lastGuard = now; return Decision(Move.GUARD, "Тактическая пауза / защита") }
        if (now - lastMagic > 11000L && Random.nextFloat() < .10f) { lastMagic = now; return Decision(Move.MAGIC, "Редкое окно для специального приёма") }
        comboIndex = (comboIndex + 1) % 5
        return when (comboIndex) {
            0, 2 -> Decision(Move.PUNCH, "Ближний бой: удар рукой")
            1, 4 -> Decision(Move.KICK, "Ближний бой: удар ногой")
            else -> Decision(Move.RETREAT, "Сбросить темп и сменить дистанцию")
        }
    }
}
