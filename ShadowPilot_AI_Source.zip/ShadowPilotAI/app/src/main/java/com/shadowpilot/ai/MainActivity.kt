package com.shadowpilot.ai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 4201
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private val bg = Color.rgb(8, 11, 20)
    private val cyan = Color.rgb(54, 217, 255)
    private val muted = Color.rgb(155, 174, 201)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }

        root.addView(label("SHADOWPILOT", 13, cyan, true).apply { letterSpacing = .22f })
        root.addView(label("AI", 42, Color.WHITE, true))
        root.addView(label("АВТОПИЛОТ ДЛЯ SHADOW FIGHT 2", 13, muted, true))
        root.addView(space(18))

        val hero = card()
        hero.addView(label("◈  COMBAT ENGINE 2.0", 14, cyan, true))
        hero.addView(label("Сам анализирует бой.\nВыбирает движение, удар и дистанцию.", 19, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(8)) })
        hero.addView(label("Экспериментальный визуальный автопилот — без обученной нейросети. Он использует эвристики и может ошибаться.", 12, muted, false))
        root.addView(hero)
        root.addView(space(14))

        val featureCard = card()
        featureCard.addView(label("БОЕВАЯ ЛОГИКА", 13, cyan, true))
        featureCard.addView(feature("✦", "Комбо", "Чередует удары руками и ногами, не зацикливаясь на одном действии."))
        featureCard.addView(feature("◉", "Дистанция", "Оценивает тёмные силуэты на экране и меняет поведение в зависимости от расстояния."))
        featureCard.addView(feature("⬡", "Дальний бой", "Периодически использует метательное оружие, если противник далеко."))
        featureCard.addView(feature("⛨", "Осторожная игра", "Иногда отходит/защищается и ограничивает частоту действий."))
        root.addView(featureCard)
        root.addView(space(14))

        val setup = card()
        setup.addView(label("БЫСТРЫЙ ЗАПУСК", 13, cyan, true))
        setup.addView(label("1  Разреши службу управления", 14, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(4)) })
        setup.addView(label("2  Нажми «Запустить автопилот» и разреши захват экрана", 13, muted, false))
        setup.addView(label("3  Переключись в игру в альбомной ориентации. Тестируй сначала в обычном бою.", 13, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(setup)
        root.addView(space(14))

        val access = button("①  Включить службу доступности", false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(access, matchWrap())
        root.addView(space(8))
        startButton = button("▶  Запустить автопилот", true) {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
        }
        root.addView(startButton, matchWrap())
        root.addView(space(8))
        root.addView(button("■  Остановить", false) {
            stopService(Intent(this, ScreenCaptureService::class.java))
            BotAccessibilityService.instance?.stopBot()
            ScreenCaptureService.running = false
            refreshStatus()
            Toast.makeText(this, "Автопилот остановлен", Toast.LENGTH_SHORT).show()
        }, matchWrap())
        root.addView(space(12))
        status = label("●  ОЖИДАНИЕ · настрой доступность перед запуском", 12, muted, true)
        root.addView(status)
        root.addView(space(16))
        root.addView(label("Важно: экран анализируется локально. Результат зависит от масштаба, ориентации и расположения кнопок в игре. Это не гарантирует победу.", 11, Color.rgb(111, 128, 153), false))
        setContentView(scroll)
        refreshStatus()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        status.text = if (ScreenCaptureService.running && BotAccessibilityService.instance?.isBotEnabled() == true) {
            "●  АВТОПИЛОТ АКТИВЕН · переключись в игру"
        } else "●  ОЖИДАНИЕ · настрой доступность перед запуском"
        status.setTextColor(if (ScreenCaptureService.running) cyan else muted)
    }

    @Deprecated("Supported for compatibility with MediaProjection permission flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra("resultCode", resultCode)
                    putExtra("resultData", data)
                }
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                BotAccessibilityService.instance?.startBot()
                status.text = "●  АВТОПИЛОТ ЗАПУЩЕН · открой игру"
                status.setTextColor(cyan)
                Toast.makeText(this, "Автопилот запущен", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "Разрешение на захват экрана не выдано", Toast.LENGTH_LONG).show()
        }
    }

    private fun feature(icon: String, title: String, desc: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(2)) }
        row.addView(label(icon, 22, cyan, true), LinearLayout.LayoutParams(dp(42), -2))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 14, Color.WHITE, true))
        col.addView(label(desc, 12, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply {
            setColor(Color.rgb(15, 21, 36)); cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.rgb(36, 76, 111))
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        includeFontPadding = true
    }

    private fun button(text: String, primary: Boolean, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 14f; isAllCaps = false; setOnClickListener { action() }
        setTextColor(if (primary) Color.rgb(4, 17, 28) else Color.WHITE)
        background = GradientDrawable().apply {
            cornerRadius = dp(13).toFloat()
            setColor(if (primary) cyan else Color.rgb(24, 32, 50))
            if (!primary) setStroke(dp(1), Color.rgb(53, 74, 105))
        }
        minHeight = dp(52)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
