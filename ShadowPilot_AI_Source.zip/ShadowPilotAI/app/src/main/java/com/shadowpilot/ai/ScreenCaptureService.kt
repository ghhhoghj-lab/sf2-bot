package com.shadowpilot.ai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import android.util.DisplayMetrics
import kotlin.math.abs

class ScreenCaptureService : Service() {
    companion object { @Volatile var running = false }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val brain = CombatBrain()
    private var lastActionAt = 0L
    private var frameCount = 0
    private var lastSceneAt = 0L
    private var noSceneFrames = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { running = false; BotAccessibilityService.instance?.stopBot(); stopSelf() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        startForeground(27, makeNotification())
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("resultData")
        if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(projectionCallback, Handler(mainLooper))
            startCapture()
            running = true
            BotAccessibilityService.instance?.startBot()
        } catch (e: Exception) {
            running = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun makeNotification(): Notification {
        val channelId = "shadowpilot_active"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "ShadowPilot AI", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = Notification.Builder(this, channelId)
        return builder.setContentTitle("ShadowPilot AI работает")
            .setContentText("Анализ экрана и управление включены")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    }

    private fun startCapture() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        thread = HandlerThread("shadowpilot-perception").also { it.start() }
        handler = Handler(thread!!.looper)
        reader!!.setOnImageAvailableListener({ source ->
            val image = try { source.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
            try {
                frameCount++
                if (frameCount % 4 == 0) analyzeFrame(image, width, height)
            } catch (_: Exception) {
                // Ignore a bad frame; next frame may be valid (e.g. during rotation).
            } finally { image.close() }
        }, handler)
        display = projection?.createVirtualDisplay(
            "ShadowPilotScreen", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
    }

    private fun analyzeFrame(image: Image, width: Int, height: Int) {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 430L) return
        val controller = BotAccessibilityService.instance ?: return
        if (!controller.isBotEnabled()) return
        if (width < height) {
            noSceneFrames++
            return
        }
        val scene = brain.analyze(image)
        if (scene == null) {
            noSceneFrames++
            // Do not attack menus/loading screens based on an untrusted guess.
            if (noSceneFrames > 12) lastSceneAt = 0L
            return
        }
        noSceneFrames = 0
        lastSceneAt = now
        val decision = brain.decide(scene, now)
        val w = width.toFloat()
        val h = height.toFloat()
        val near = scene.distance < .18f
        when (decision.move) {
            CombatBrain.Move.APPROACH -> moveStick(controller, w, h, right = true)
            CombatBrain.Move.PUNCH -> controller.tap(w * .925f, h * .695f)
            CombatBrain.Move.KICK -> controller.tap(w * .86f, h * .835f)
            CombatBrain.Move.THROW -> controller.tap(w * .82f, h * .695f)
            CombatBrain.Move.MAGIC -> controller.tap(w * .91f, h * .555f)
            CombatBrain.Move.RETREAT -> moveStick(controller, w, h, right = false)
            CombatBrain.Move.GUARD -> {
                // SF2 has no universal block button; a short back/down input is safer than
                // pretending a dedicated block button exists on every version.
                val cx = w * .27f; val cy = h * .76f
                controller.swipe(cx, cy, cx - w * .055f, cy + h * .035f, 150L)
            }
        }
        lastActionAt = now
    }

    private fun moveStick(controller: BotAccessibilityService, w: Float, h: Float, right: Boolean) {
        val cx = w * .27f
        val cy = h * .76f
        val delta = w * if (right) .075f else -.075f
        controller.swipe(cx, cy, (cx + delta).coerceIn(w * .12f, w * .43f), cy, 190L)
    }

    override fun onDestroy() {
        running = false
        BotAccessibilityService.instance?.stopBot()
        try { display?.release() } catch (_: Exception) {}
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) {}
        try { projection?.unregisterCallback(projectionCallback); projection?.stop() } catch (_: Exception) {}
        thread?.quitSafely()
        super.onDestroy()
    }
}
